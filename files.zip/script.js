// ===================================================================
// script.js — Grão & Cia
// Controla o painel de horário de funcionamento (abre/fecha).
// Escrito pelo estagiário anterior.
// ===================================================================

var aberto = false;
var contador = 0; // ia servir para contar quantas vezes o painel foi aberto, mas ninguém terminou isso

function alternarHorario() {
    var painel = document.getElementById("painelHorario");

    if (aberto == false) {
        painel.style.display = "block";
        aberto = true;
    } else {
        painel.style.display = "none";
        aberto = false;
    }
}
