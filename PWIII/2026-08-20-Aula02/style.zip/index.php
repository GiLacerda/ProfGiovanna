<?php
require_once "conn.php";

$stmt = $pdo->prepare("SELECT id, usuario, nickname, cor FROM usuario");
$stmt->execute();

$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<HTML>
    <HEAD>
        <META CHARSET="UTF-8"/>
        <LINK HREF="style.css" REL="STYLESHEET"/>
        <TITLE>Candy Crush</TITLE>
    </HEAD>
    <BODY>
        <H1>Lista de usuários</H1>
        <A HREF="cadastro.php" CLASS="btn-novo">Novo +</A>
        <TABLE>
            <TR>
                <TH>ID</TH>
                <TH>Usuário</TH>
                <TH>Nick</TH>
                <TH>Cor</TH>
            </TR>
            <?php
            foreach ($usuarios as $usuario) {
                echo "<TR>";
                echo "<TD>".$usuario['id']."</TD>";
                echo "<TD>".$usuario['usuario']."</TD>";
                echo "<TD>".$usuario['nickname']."</TD>";
                echo "<TD><span class='color-badge' style='background-color: ".$usuario['cor'].";'></span>".$usuario['cor']."</TD>";
                echo "</TR>";
            }
            ?>
        </TABLE>
    </BODY>
</HTML>