<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once "conn.php";

    $sql = "INSERT INTO usuario (usuario, nickname, cor)
            VALUES (:usuario, :nickname, :cor)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($_POST);

    header("Location: ./index.php");
}
?>
<HTML>
    <HEAD>
        <META CHARSET="UTF-8"/>
        <LINK HREF="style.css" REL="STYLESHEET"/>
        <TITLE>Candy Crush</TITLE>
    </HEAD>
    <BODY>
        <H1>Cadastro de usuários</H1>
        <FORM ACTION="cadastro.php" METHOD="POST">
            <INPUT TYPE="TEXT" NAME="usuario" PLACEHOLDER="User" REQUIRED/><BR/>
            <INPUT TYPE="TEXT" NAME="nickname" PLACEHOLDER="Nick" REQUIRED/><BR/>
            <INPUT TYPE="COLOR" NAME="cor" PLACEHOLDER="Cor"/><BR/>
            <BUTTON TYPE="SUBMIT">Enviar</BUTTON>
        </FORM>
    </BODY>
</HTML>