<?php

$host    = 'localhost';   // onde o banco está rodando
$dbname  = 'modular_pwiii';    // nome do banco
$usuario = 'root';
$senha   = '';

$dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $usuario, $senha);
    //echo "Conectado com sucesso!";
} catch (PDOException $e) {
    die("Erro ao conectar: " . $e->getMessage());
}